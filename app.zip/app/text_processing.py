import codecs
from langdetect import detect
import nltk
import re
import operator
import os
import sys

modules_path = os.path.dirname(__file__)
modules_path = os.path.join(modules_path, 'lib')
sys.path.append(modules_path)


# Language information
class LanguageInfo:

	def __init__(self, lang, wc, percent):
		self.language = lang
		self.wc = wc
		self.percent = percent


# Results structure
class ProcessingResult:

	def __init__(self, content, top, lang_info):
		self.content = content
		self.top = top
		self.lang_info = lang_info

	def to_dict(self, filename):
		return {"filename": filename,
				"content": self.content,
		        "top": self.top,
		        "info": self.lang_info}



from converter import (
	converter,
	langdetect,
	textpairs,
	tokenizer,
	aligner,
	detokenizer,
	originalkeeper,
	tsvconverter,
	tmxconverter,
)

MODE_SENTENCES = 0
MODE_BIGRAMS = 1
UNRECOGNIZED = "unrecognized"

def convert_files(dir, out_dir):
	return converter.convert_dir(dir, out_dir)


def get_content(filepath, mode, top_n):
	content = None
	with codecs.open(filepath, "r", "utf-8", errors="ignore") as f:
		content = f.read()

	result = _langs(content, mode, top_n)
	result.content = _line_breaks(result.content)
	return result


def _line_breaks(content):
	return content.replace("\n", "<br>")


def _langs(content, mode, top_n):

	detected = None
	if mode == MODE_SENTENCES:
		tokens = nltk.sent_tokenize(content)
		detected = _get_sentences(tokens)
	elif mode == MODE_BIGRAMS:
		tokens = nltk.word_tokenize(content)
		detected = _get_bigrams(tokens)
	else:
		raise RuntimeError("unsupported processing mode")

	# tokenizer removing punctuation
	tokenizer = nltk.tokenize.RegexpTokenizer(r'\w+')

	# language to word count dict
	languages = {lang: 0 for key, lang in detected.items()}
	languages[UNRECOGNIZED] = 0 # always add unrecognized languaged in order to not break a template

	# counting words
	for key, lang in detected.items():
		key_words = tokenizer.tokenize(key)
		languages[lang] += len(key_words)

	# sorting languages dictionary to see a rating
	sorted_languages = list(reversed(sorted(languages.items(), key=operator.itemgetter(1))))

	# getting top_n (or less) from found languages
	top = [sorted_languages[i][0] for i in range(0, min(top_n, len(sorted_languages)))]

	# words count in the whole document
	document_wc = sum(wc for lang, wc in languages.items())
	# languages info dict
	lang_info = {lang: LanguageInfo(lang, wc, wc * 100 / document_wc) for lang, wc in languages.items()}

	# highlighting sentences from top n languages
	for ngram, language in detected.items():
		if not language in top or language == UNRECOGNIZED:
			continue

		lang_number = top.index(language) + 1
		found = re.findall(re.escape(ngram), content, re.IGNORECASE)
		for f in found:
			content = content.replace(f, "<span class=\"lang{0}\">{1}</span>".format(lang_number, f))

	return ProcessingResult(content, top, lang_info)


def _get_sentences(tokens):
	tokens = [token.lower() for token in tokens if len(token) > 1]

	langs = {}
	for token in tokens:
		try:
			lang = detect(token)
			langs[token] = lang
		except:
			langs[token] = UNRECOGNIZED

	return langs


def _get_bigrams(tokens):
	tokens = [token.lower() for token in tokens if len(token) > 1]
	bigrams = nltk.ngrams(tokens, 2)

	langs = {}
	for b in bigrams:
		try:
			bigram_key = "{0} {1}".format(b[0], b[1])
			lang = detect(bigram_key)
			langs[bigram_key] = lang
		except:
			langs[bigram_key] = UNRECOGNIZED

	return langs
