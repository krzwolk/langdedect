
import pdfkit


def convert_to_pdf(input, output):
	pdfkit.from_string(input, output)
