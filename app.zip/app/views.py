from app import app
import os
import shutil
import ntpath
import tempfile

from flask import Flask, request, redirect, url_for, render_template, flash, send_from_directory
from werkzeug.utils import secure_filename
from text_processing import get_content, convert_files, MODE_SENTENCES, MODE_BIGRAMS
from pdf_convert import convert_to_pdf

APP_TITLE = "Language detection"
RESULT_TITLE = "Results"
TEMP_DIR = "tmp"
PDF_EXT = ".pdf"

processing_type = {"Sentences": MODE_SENTENCES,
					"Bigrams": MODE_BIGRAMS}


def allowed_file(filename):
	return "." in filename and \
		   filename.rsplit(".", 1)[1] in app.config["ALLOWED_EXTENSIONS"]


def text_file(filename):
	return filename.rsplit(".", 1)[1] == "txt"


@app.route('/downloads/<path:filename>', methods=['GET', 'POST'])
def download(filename):
    return send_from_directory(app.config['DOWNLOAD_FOLDER'], filename=filename)


@app.route("/", methods=["GET", "POST"])
@app.route("/index", methods=["GET", "POST"])
def upload_file():
	if request.method == "POST":
		temp_directory = path_leaf(tempfile.NamedTemporaryFile(prefix="files_").name)
		path = os.path.join(app.config["UPLOAD_FOLDER"], temp_directory)
		ensure_dir(path)

		proc_type = processing_type[request.form.get("proctype")]
		top_n = int(request.form.get("top_n"))
		if top_n < 1 or top_n > 10:
			flash("Number of languages must be from 1 to 10")
			return redirect(request.url)

		text_files = {}
		# check if the post request has the file part
		uploaded_files = request.files.getlist("file[]")
		for file in uploaded_files:
			# if user does not select file, browser also
			# submit a empty part without filename
			if not file or file.filename == "":
				flash("No selected file")
				return redirect(request.url)

			if not allowed_file(file.filename):
				flash("Allowed file extensions are: {0}".format(", ".join(app.config["ALLOWED_EXTENSIONS"])))
				return redirect(request.url)

			filename = secure_filename(file.filename)
			filepath = os.path.join(path, filename)
			file.save(filepath)
			if text_file(filename):
				text_files[filename] = filepath

		# converting uploaded files
		out_path = os.path.join(path, TEMP_DIR)
		ensure_dir(out_path)
		converted_files = convert_files(path, out_path)

		files_content = {}
		# parsing uploaded and converted files
		for original, converted in converted_files.items():
			fname = path_leaf(original)
			result = get_content(converted, proc_type, top_n)
			files_content[fname] = result.to_dict(fname)

		# parsing plain text files
		for fname, fpath in text_files.items():
			result = get_content(fpath, proc_type, top_n)
			files_content[fname] = result.to_dict(fname)

		# converting to pdf
		download_path = os.path.join(app.config["DOWNLOAD_FOLDER"], temp_directory)
		ensure_dir(download_path)

		# convert all output to pdf
		for fname, content in files_content.items():
			html = render_template("pdf_template.html",
			                       title=APP_TITLE,
			                       content_title=RESULT_TITLE,
			                       value=content)

			pdf_name = fname + PDF_EXT
			convert_to_pdf(html, os.path.join(download_path, pdf_name))
			content["url"] = os.path.join("/downloads", temp_directory, pdf_name)

		# remove all files
		shutil.rmtree(path)


		rendered = render_template("result.html",
		                           title=APP_TITLE,
		                           content_title=RESULT_TITLE,
		                           files_content = files_content)
		return rendered

	return render_template("upload.html", title=APP_TITLE, content_title="Uploading files")

def ensure_dir(directory):
	if not os.path.exists(directory):
		os.makedirs(directory)


def path_leaf(path):
	head, tail = ntpath.split(path)
	return tail or ntpath.basename(head)