from flask import Flask

UPLOAD_FOLDER = "/var/www/web_langdetect/app/upload"
DOWNLOAD_FOLDER = "/var/www/web_langdetect/app/download"
ALLOWED_EXTENSIONS = set(["txt", "doc", "docx"])

app = Flask(__name__)
app.secret_key = "{8D08315D-B768-4CAA-BB54-44FA0BC257E1}"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["DOWNLOAD_FOLDER"] = DOWNLOAD_FOLDER
app.config["ALLOWED_EXTENSIONS"] = ALLOWED_EXTENSIONS


def get_resource_as_string(name, charset='utf-8'):
	with app.open_resource(name) as f:
		return f.read().decode(charset)

app.jinja_env.globals['get_resource_as_string'] = get_resource_as_string
from app import views